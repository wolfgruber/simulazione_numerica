For compiling and running the programmes, simply run the script 'eserc01.sh'. Rise the flag '-p' to automatically launch the jupyter-notebook.
